try {
    const students = require('./routes/students');
    console.log('✅ students.js loaded:', typeof students);
    console.log('students has post?', typeof students.post);
    
    const menuItems = require('./routes/menuItems');
    console.log('✅ menuItems.js loaded:', typeof menuItems);
    
    const orders = require('./routes/orders');
    console.log('✅ orders.js loaded:', typeof orders);
    
    const analytics = require('./routes/analytics');
    console.log('✅ analytics.js loaded:', typeof analytics);
} catch (err) {
    console.error('❌ Error:', err.message);
}